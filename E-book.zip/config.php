<?php

$conn = mysqli_connect('localhost:3307','root','','ebook') or die('connection failed');

?>
